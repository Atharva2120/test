module FixturesHelper
  def self.fixtures
    [:custom_fields, :issues, :trackers,
     :projects, :custom_fields_trackers,
     :time_entries, :enumerations, :custom_values,
     :issue_statuses, :users]
  end
end
